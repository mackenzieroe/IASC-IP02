function openNav() {
    document.getElementById("sideNav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("sideNav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}


var slideIndex = 1;
showPic(slideIndex);

function pic(n) {
  showPic(slideIndex += n);

}

function showPic(n) {
  var i;
  var x = document.getElementsByClassName("myPic");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  x[slideIndex-1].style.display = "block";
}


var slideIndex = 1;
showPic1(slideIndex);

function pic1(n) {
  showPic1(slideIndex += n);

}

function showPic1(n) {
  var i;
  var x = document.getElementsByClassName("myPic1");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  x[slideIndex-1].style.display = "block";
}







function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById("time").innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};
    return i;
}

function myFunction() {
    alert("WELCOME TO THE PAGE! ENJOY!");
}



function move() {
  var elem = document.getElementById("myBar");
  var width = 10;
  var id = setInterval(frame, 5);
  function frame() {
    if (width >= 80) {
      clearInterval(id);
    } else {
      width++;
      elem.style.width = width + '%';
      elem.innerHTML = width * 1  + '%';
    }
  }
}
